﻿import React from 'react';
import ReactDOM from 'react-dom';
import ReactPlayer from 'react-player';

export default class TalentCardDetail extends React.Component {
    render() {
        
    }
}